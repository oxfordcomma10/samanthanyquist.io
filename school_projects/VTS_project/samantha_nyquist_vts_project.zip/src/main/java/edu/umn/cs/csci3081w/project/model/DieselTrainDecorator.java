package edu.umn.cs.csci3081w.project.model;

public class DieselTrainDecorator extends VehicleDecorator {
  public DieselTrainDecorator(Vehicle vehicle) {
    super(vehicle);
  }

  @Override
  public boolean provideInfo() {
    return false;
  }

  @Override
  public void setVehicleSubject(VehicleConcreteSubject vehicleConcreteSubject){
  }

  @Override
  public int getRed() {
    return 255;
  }

  @Override
  public int getGreen() {
    return 204;
  }

  @Override
  public int getBlue() {
    return 51;
  }

  @Override
  public int getAlpha() {
    return 255;
  }
}
