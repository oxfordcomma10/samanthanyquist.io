package edu.umn.cs.csci3081w.project.model;

public class LargeBusDecorator extends VehicleDecorator {
  public LargeBusDecorator(Vehicle vehicle) {
    super(vehicle);
  }

  @Override
  public boolean provideInfo() {
    return false;
  }

  @Override
  public void setVehicleSubject(VehicleConcreteSubject vehicleConcreteSubject) {
  }

  @Override
  public int getRed() {
    return 239;
  }

  @Override
  public int getGreen() {
    return 130;
  }

  @Override
  public int getBlue() {
    return 238;
  }

  @Override
  public int getAlpha() {
    return 255;
  }
}
