package edu.umn.cs.csci3081w.project.model;

public interface VehicleObserver {

  public boolean provideInfo();

  public void setVehicleSubject(VehicleConcreteSubject vehicleConcreteSubject);

  public int getRed();

  public int getGreen();

  public int getBlue();

  public int getAlpha();
}
