package edu.umn.cs.csci3081w.project.model;

public class SmallBusDecorator extends VehicleDecorator {
  public SmallBusDecorator(Vehicle vehicle) {
    super(vehicle);
  }

  @Override
  public boolean provideInfo() {
    return false;
  }

  @Override
  public void setVehicleSubject(VehicleConcreteSubject vehicleConcreteSubject) {
  }

  @Override
  public int getRed() {
    return 122;
  }

  @Override
  public int getGreen() {
    return 0;
  }

  @Override
  public int getBlue() {
    return 25;
  }

  @Override
  public int getAlpha() {
    return 255;
  }

}
