package edu.umn.cs.csci3081w.project.model;

public abstract class VehicleDecorator implements VehicleObserver {
  protected Vehicle vehicle;

  public VehicleDecorator(Vehicle vehicle) {
    this.vehicle = vehicle;
  }

  @Override
  public boolean provideInfo() {
    return false;
  }

  @Override
  public void setVehicleSubject(VehicleConcreteSubject vehicleConcreteSubject){
  }

  public int getRed() {
    return vehicle.getRed();
  }

  public int getGreen() {
    return vehicle.getGreen();
  }

  public int getBlue() {
    return vehicle.getBlue();
  }

  public int getAlpha() {
    return vehicle.getAlpha();
  }
}
