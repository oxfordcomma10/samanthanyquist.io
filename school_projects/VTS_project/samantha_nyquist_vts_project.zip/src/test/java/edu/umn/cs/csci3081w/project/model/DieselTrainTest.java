package edu.umn.cs.csci3081w.project.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import com.google.gson.JsonObject;
import edu.umn.cs.csci3081w.project.webserver.WebServerSession;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import javax.websocket.Session;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;


public class DieselTrainTest {

  private Train testTrain;
  private Route testRouteIn;
  private Route testRouteOut;


  /**
   * Setup operations before each test runs.
   */
  @BeforeEach
  public void setUp() {
    List<Stop> stopsIn = new ArrayList<Stop>();
    Stop stop1 = new Stop(0, "test stop 1", new Position(-93.243774, 44.972392));
    Stop stop2 = new Stop(1, "test stop 2", new Position(-93.235071, 44.973580));
    stopsIn.add(stop1);
    stopsIn.add(stop2);
    List<Double> distancesIn = new ArrayList<>();
    distancesIn.add(0.843774422231134);
    List<Double> probabilitiesIn = new ArrayList<Double>();
    probabilitiesIn.add(.025);
    probabilitiesIn.add(0.3);
    PassengerGenerator generatorIn = new RandomPassengerGenerator(stopsIn, probabilitiesIn);

    testRouteIn = new Route(0, "testRouteIn",
        stopsIn, distancesIn, generatorIn);

    List<Stop> stopsOut = new ArrayList<Stop>();
    stopsOut.add(stop2);
    stopsOut.add(stop1);
    List<Double> distancesOut = new ArrayList<>();
    distancesOut.add(0.843774422231134);
    List<Double> probabilitiesOut = new ArrayList<Double>();
    probabilitiesOut.add(0.3);
    probabilitiesOut.add(.025);
    PassengerGenerator generatorOut = new RandomPassengerGenerator(stopsOut, probabilitiesOut);

    testRouteOut = new Route(1, "testRouteOut",
        stopsOut, distancesOut, generatorOut);

    testTrain = new DieselTrain(1,
        new Line(10000, "testLine", "TRAIN", testRouteOut, testRouteIn, new Issue()),
        3, 1.0);
  }

  /**
   * Tests constructor.
   */
  @Test
  public void testConstructor() {
    assertEquals(1, testTrain.getId());
    assertEquals("testRouteOut1", testTrain.getName());
    assertEquals(3, testTrain.getCapacity());
    assertEquals(1, testTrain.getSpeed());
    assertEquals(testRouteOut, testTrain.getLine().getOutboundRoute());
    assertEquals(testRouteIn, testTrain.getLine().getInboundRoute());
  }

  /**
   * Tests if updateDistance function works properly.
   */
  @Test
  public void testReport() {
    testTrain.move();
    Passenger testPassenger = new Passenger(5, "goldy");
    testTrain.loadPassenger(testPassenger);
    try {
      final Charset charset = StandardCharsets.UTF_8;
      ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
      PrintStream testStream = new PrintStream(outputStream, true, charset.name());
      testTrain.report(testStream);
      outputStream.flush();
      String data = new String(outputStream.toByteArray(), charset);
      testStream.close();
      outputStream.close();
      String strToCompare =
          "####Diesel Train Info Start####" + System.lineSeparator()
              + "ID: 1" + System.lineSeparator()
              + "Name: testRouteOut1" + System.lineSeparator()
              + "Speed: 1.0" + System.lineSeparator()
              + "Capacity: 3" + System.lineSeparator()
              + "Position: 44.97358,-93.235071" + System.lineSeparator()
              + "Distance to next stop: 0.843774422231134" + System.lineSeparator()
              + "****Passengers Info Start****" + System.lineSeparator()
              + "Num of passengers: 1" + System.lineSeparator()
              + "####Passenger Info Start####" + System.lineSeparator()
              + "Name: goldy" + System.lineSeparator()
              + "Destination: 5" + System.lineSeparator()
              + "Wait at stop: 0" + System.lineSeparator()
              + "Time on vehicle: 1" + System.lineSeparator()
              + "####Passenger Info End####" + System.lineSeparator()
              + "****Passengers Info End****" + System.lineSeparator()
              + "####Diesel Train Info End####" + System.lineSeparator();
      assertEquals(strToCompare, data);
    } catch (IOException ioe) {
      fail();
    }
  }

  /**
   * Test the co2 calculation for a train.
   */
  @Test
  public void testCurrentCO2Emission() {
    assertEquals(6, testTrain.getCurrentCO2Emission());
    Passenger testPassenger1 = new Passenger(3, "testPassenger1");
    testTrain.loadPassenger(testPassenger1);
    assertEquals(8, testTrain.getCurrentCO2Emission());
  }

  /**
   * Test to see if observer got attached.
   */
  @Test
  public void testProvideInfo() {
    testTrain.update();
    Passenger testPassenger = new Passenger(5, "goldy");
    testTrain.loadPassenger(testPassenger);

    //create webserver spy
    WebServerSession webServerSessionSpy = spy(WebServerSession.class);
    //tell the mock to do nothing when sendJson is called
    doNothing().when(webServerSessionSpy).sendJson(Mockito.isA(JsonObject.class));
    //make session dummy
    Session sessionDummy = mock(Session.class);
    //have spy webserver use the session dummy on open
    webServerSessionSpy.onOpen(sessionDummy);

    VehicleConcreteSubject vcs = new VehicleConcreteSubject(webServerSessionSpy);
    testTrain.setVehicleSubject(vcs);

    //prepare test input
    JsonObject testData = new JsonObject();
    testData.addProperty("command", "observedVehicle");
    testData.addProperty("text", "1" + System.lineSeparator()
        + "-----------------------------" + System.lineSeparator()
        + "* Type: DIESEL_TRAIN_VEHICLE" + System.lineSeparator()
        + "* Position: (-93.235071,44.973580)" + System.lineSeparator()
        + "* Passengers: 1" + System.lineSeparator()
        + "* CO2: 6" + System.lineSeparator());

    //send test input to session
    webServerSessionSpy.onMessage(testData.toString());
    
    testTrain.provideInfo();

    //capture object sent
    ArgumentCaptor<JsonObject> messageCaptor = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor.capture());

    //check output values
    JsonObject message = messageCaptor.getValue();

    String command = message.get("command").getAsString();

    String expectedCommand = "observedVehicle";
    assertEquals(expectedCommand, command);


    String observedText = message.get("text").getAsString();
    String expectedText = "1" + System.lineSeparator()
            + "-----------------------------" + System.lineSeparator()
            + "* Type: DIESEL_TRAIN_VEHICLE" + System.lineSeparator()
            + "* Position: (-93.235071,44.973580)" + System.lineSeparator()
            + "* Passengers: 1" + System.lineSeparator()
            + "* CO2: 6" + System.lineSeparator();
    assertEquals(expectedText, observedText);
  }

  /**
   * Clean up our variables after each test.
   */
  @AfterEach
  public void cleanUpEach() {
    testTrain = null;
  }

}
