package edu.umn.cs.csci3081w.project.webserver;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import edu.umn.cs.csci3081w.project.model.PassengerFactory;
import edu.umn.cs.csci3081w.project.model.RandomPassengerGenerator;
import javax.websocket.Session;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class WebServerSessionTest {
  /**
   * Setup deterministic operations before each test runs.
   */
  @BeforeEach
  public void setUp() {
    PassengerFactory.DETERMINISTIC = true;
    PassengerFactory.DETERMINISTIC_NAMES_COUNT = 0;
    PassengerFactory.DETERMINISTIC_DESTINATION_COUNT = 0;
    RandomPassengerGenerator.DETERMINISTIC = true;
  }

  /**
   * Test command for initializing the simulation.
   */
  @Test
  public void testSimulationInitialization() {
    WebServerSession webServerSessionSpy = spy(WebServerSession.class);
    doNothing().when(webServerSessionSpy).sendJson(Mockito.isA(JsonObject.class));
    Session sessionDummy = mock(Session.class);
    webServerSessionSpy.onOpen(sessionDummy);
    JsonObject commandFromClient = new JsonObject();
    commandFromClient.addProperty("command", "initLines");
    webServerSessionSpy.onMessage(commandFromClient.toString());
    ArgumentCaptor<JsonObject> messageCaptor = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor.capture());
    JsonObject commandToClient = messageCaptor.getValue();
    assertEquals("3", commandToClient.get("numLines").getAsString());
  }

  /**
   * Test command for starting the simulation, a print statement verifies this works correctly.
   */
  @Test
  public void testSimulationStart() {
    WebServerSession webServerSessionSpy = spy(WebServerSession.class);
    doNothing().when(webServerSessionSpy).sendJson(Mockito.isA(JsonObject.class));
    Session sessionDummy = mock(Session.class);
    webServerSessionSpy.onOpen(sessionDummy);
    JsonObject commandFromClient = new JsonObject();
    commandFromClient.addProperty("command", "initLines");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    ArgumentCaptor<JsonObject> messageCaptor = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor.capture());
    JsonObject commandToClient = messageCaptor.getValue();
    assertEquals("3", commandToClient.get("numLines").getAsString());


    commandFromClient.addProperty("command", "start");
    commandFromClient.addProperty("numTimeSteps", 50);
    JsonArray arry = new JsonArray();
    arry.add(5);
    arry.add(10);
    commandFromClient.add("timeBetweenVehicles", arry);
    webServerSessionSpy.onMessage(commandFromClient.toString());

    ArgumentCaptor<JsonObject> messageCaptor2 = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor2.capture());
    //Start command does not add any properties so as long as it prints
    // to the command line we know it is working.
  }

  /**
   * Test command for getting vehicles and routes with logging.
   */
  @Test
  public void testSimulationUpdateWithLogging() {
    VisualTransitSimulator.LOGGING = true;
    WebServerSession webServerSessionSpy = spy(WebServerSession.class);
    doNothing().when(webServerSessionSpy).sendJson(Mockito.isA(JsonObject.class));
    Session sessionDummy = mock(Session.class);
    webServerSessionSpy.onOpen(sessionDummy);
    JsonObject commandFromClient = new JsonObject();
    commandFromClient.addProperty("command", "initLines");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    ArgumentCaptor<JsonObject> messageCaptor = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor.capture());
    JsonObject commandToClient = messageCaptor.getValue();
    assertEquals("3", commandToClient.get("numLines").getAsString());


    commandFromClient.addProperty("command", "start");
    commandFromClient.addProperty("numTimeSteps", 50);
    JsonArray arry = new JsonArray();
    arry.add(5);
    arry.add(10);
    commandFromClient.add("timeBetweenVehicles", arry);
    webServerSessionSpy.onMessage(commandFromClient.toString());

    ArgumentCaptor<JsonObject> messageCaptor2 = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor2.capture());

    for (int i = 0; i < 50; i++) {
      commandFromClient.addProperty("command", "getRoutes");
      webServerSessionSpy.onMessage(commandFromClient.toString());

      commandFromClient.addProperty("command", "getVehicles");
      webServerSessionSpy.onMessage(commandFromClient.toString());

      commandFromClient.addProperty("command", "update");
      webServerSessionSpy.onMessage(commandFromClient.toString());
    }
    //This test is confirmed through print statements shown in the log
  }

  /**
   * Test command for registering a vehicle.
   */
  @Test
  public void testSimulationUpdateWithRegisterVehicle() {
    WebServerSession webServerSessionSpy = spy(WebServerSession.class);
    doNothing().when(webServerSessionSpy).sendJson(Mockito.isA(JsonObject.class));
    Session sessionDummy = mock(Session.class);
    webServerSessionSpy.onOpen(sessionDummy);
    JsonObject commandFromClient = new JsonObject();
    commandFromClient.addProperty("command", "initLines");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    ArgumentCaptor<JsonObject> messageCaptor = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor.capture());
    JsonObject commandToClient = messageCaptor.getValue();
    assertEquals("3", commandToClient.get("numLines").getAsString());


    commandFromClient.addProperty("command", "start");
    commandFromClient.addProperty("numTimeSteps", 50);
    JsonArray arry = new JsonArray();
    arry.add(5);
    arry.add(10);
    commandFromClient.add("timeBetweenVehicles", arry);
    webServerSessionSpy.onMessage(commandFromClient.toString());

    commandFromClient.addProperty("command", "getRoutes");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    commandFromClient.addProperty("command", "getVehicles");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    commandFromClient.addProperty("command", "update");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    commandFromClient.addProperty("command", "registerVehicle");
    commandFromClient.addProperty("id", "1000");
    webServerSessionSpy.onMessage(commandFromClient.toString());
    assertEquals(1000, commandFromClient.get("id").getAsInt());

  }

  /**
   * Test command for creating a line issue.
   */
  @Test
  public void testSimulationLineIssue() {
    WebServerSession webServerSessionSpy = spy(WebServerSession.class);
    doNothing().when(webServerSessionSpy).sendJson(Mockito.isA(JsonObject.class));
    Session sessionDummy = mock(Session.class);
    webServerSessionSpy.onOpen(sessionDummy);
    JsonObject commandFromClient = new JsonObject();
    commandFromClient.addProperty("command", "initLines");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    ArgumentCaptor<JsonObject> messageCaptor = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor.capture());
    JsonObject commandToClient = messageCaptor.getValue();
    assertEquals("3", commandToClient.get("numLines").getAsString());


    commandFromClient.addProperty("command", "start");
    commandFromClient.addProperty("numTimeSteps", 50);
    JsonArray arry = new JsonArray();
    arry.add(5);
    arry.add(10);
    commandFromClient.add("timeBetweenVehicles", arry);
    webServerSessionSpy.onMessage(commandFromClient.toString());

    ArgumentCaptor<JsonObject> messageCaptor2 = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor2.capture());


    commandFromClient.addProperty("command", "update");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    commandFromClient.addProperty("command", "lineIssue");
    commandFromClient.addProperty("id", "10000");
    webServerSessionSpy.onMessage(commandFromClient.toString());
    ArgumentCaptor<JsonObject> messageCaptor3 = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor3.capture());
    JsonObject commandToClient3 = messageCaptor.getValue();
    String lines = commandToClient3.get("lines").toString();

    commandFromClient.addProperty("command", "update");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    assertEquals(lines, commandToClient3.get("lines").toString());
  }

  /**
   * Test Update functionality when updating more than total time steps.
   */
  @Test
  public void testSimulationUpdateMoreThanTimeSteps() {
    VisualTransitSimulator.LOGGING = false;
    WebServerSession webServerSessionSpy = spy(WebServerSession.class);
    doNothing().when(webServerSessionSpy).sendJson(Mockito.isA(JsonObject.class));
    Session sessionDummy = mock(Session.class);
    webServerSessionSpy.onOpen(sessionDummy);
    JsonObject commandFromClient = new JsonObject();
    commandFromClient.addProperty("command", "initLines");
    webServerSessionSpy.onMessage(commandFromClient.toString());

    ArgumentCaptor<JsonObject> messageCaptor = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor.capture());
    JsonObject commandToClient = messageCaptor.getValue();
    assertEquals("3", commandToClient.get("numLines").getAsString());


    commandFromClient.addProperty("command", "start");
    commandFromClient.addProperty("numTimeSteps", 50);
    JsonArray arry = new JsonArray();
    arry.add(5);
    arry.add(10);
    commandFromClient.add("timeBetweenVehicles", arry);
    webServerSessionSpy.onMessage(commandFromClient.toString());

    ArgumentCaptor<JsonObject> messageCaptor2 = ArgumentCaptor.forClass(JsonObject.class);
    verify(webServerSessionSpy).sendJson(messageCaptor2.capture());



    for (int i = 0; i < 51; i++) {

      commandFromClient.addProperty("command", "getRoutes");
      webServerSessionSpy.onMessage(commandFromClient.toString());

      commandFromClient.addProperty("command", "getVehicles");
      webServerSessionSpy.onMessage(commandFromClient.toString());

      commandFromClient.addProperty("command", "update");
      webServerSessionSpy.onMessage(commandFromClient.toString());

    }
    //Check time steps to ensure it doesn't update past 50
  }
}
