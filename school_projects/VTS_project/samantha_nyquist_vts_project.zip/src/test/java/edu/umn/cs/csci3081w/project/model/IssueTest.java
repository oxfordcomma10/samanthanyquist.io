package edu.umn.cs.csci3081w.project.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class IssueTest {

  /**
   * Tests constructor.
   */
  @Test
  public void testConstructor() {
    Issue issueTest = new Issue();
    assertEquals(0, issueTest.getCounter());
  }

  /**
   * Tests the decrementCounter function.
   */
  @Test
  public void testDecrementCouter() {
    Issue issueTest = new Issue();
    assertEquals(0, issueTest.getCounter());
    issueTest.decrementCounter();
    assertEquals(-1, issueTest.getCounter());
  }

  /**
   * Tests the createIssue function.
   */
  @Test
  public void testCreateIssue() {
    Issue issueTest = new Issue();
    assertEquals(0, issueTest.getCounter());
    issueTest.createIssue();
    assertEquals(10, issueTest.getCounter());
  }

  /**
   * Tests the isIssueResolved function.
   */
  @Test
  public void testIsIssueResolved() {
    Issue issueTest = new Issue();
    assertEquals(0, issueTest.getCounter());
    issueTest.createIssue();
    assertEquals(10, issueTest.getCounter());
    assertEquals(false, issueTest.isIssueResolved());
    for (int i = 0; i < 10; i++) {
      issueTest.decrementCounter();
    }
    assertEquals(true, issueTest.isIssueResolved());
  }
}
