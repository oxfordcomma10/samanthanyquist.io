package edu.umn.cs.csci3081w.project.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PassengerFactoryTest {


  /**
   * Setup deterministic operations before each test run.
   */
  @BeforeEach
  public void setUp() {
    PassengerFactory.DETERMINISTIC = true;
    PassengerFactory.DETERMINISTIC_NAMES_COUNT = 0;
    PassengerFactory.DETERMINISTIC_DESTINATION_COUNT = 0;
    RandomPassengerGenerator.DETERMINISTIC = true;
  }

  /**
   * Tests generate function.
   */
  @Test
  public void testGenerate() {

    PassengerFactory.DETERMINISTIC = true;
    PassengerFactory.DETERMINISTIC_NAMES_COUNT = 0;
    assertEquals(3, PassengerFactory.generate(1, 10).getDestination());

  }

  /**
   * Tests generate function without deterministic for full branch coverage.
   */
  @Test
  public void testGenerateNonDeterministic() {

    PassengerFactory.DETERMINISTIC = false;
    if (PassengerFactory.generate(1, 10).getDestination() != 0) {
      assertEquals(true, true);
    } else {
      assertEquals(true, false);
    }

  }

  /**
   * Tests generate function.
   */
  @Test
  public void nameGeneration() {

    PassengerFactory.DETERMINISTIC = true;
    PassengerFactory.DETERMINISTIC_NAMES_COUNT = 0;

    assertEquals("Goldy", PassengerFactory.nameGeneration());

  }

  /**
   * Tests generate function without deterministic for full branch coverage.
   */
  @Test
  public void nameGenerationNondeterministic() {

    PassengerFactory.DETERMINISTIC = false;

    if (PassengerFactory.nameGeneration() != null) {
      assertEquals(true, true);
    } else {
      assertEquals(true, false);
    }

  }


  /**
   * Clean up our variables after each test.
   */
  @AfterEach
  public void cleanUpEach() {
    PassengerFactory.DETERMINISTIC = false;
  }


}
